export function Input(props) {
  return <input className="border p-2 w-full rounded" {...props} />;
}