export function Textarea(props) {
  return <textarea className="border p-2 w-full rounded" rows="3" {...props} />;
}