import EvidenceVyroby from "../components/EvidenceVyroby";

export default function Page() {
  return <EvidenceVyroby />;
}